#include "stm32f1xx.h"

int main(void) {

	while(1) {

	}
}
