#include "stm32f1xx.h"
#include "RCC//RCC.h"
#include "GPIO/GPIO.h"
#include "SysTickHandle/SysTickHandle.h"

int main(void) {
	GPIOB_CLK_ENABLE();
	digital_output_init(GPIOB, GPIO_PIN_10);

	while(1) {

	}
}

void SysTick_Hook(void) {
	pin_toggle(GPIOB, GPIO_PIN_10);
}
