#ifndef SYSTICKHANDLE_H_
#define SYSTICKHANDLE_H_

#include "stm32f1xx.h"

__attribute__((weak)) void SysTick_Hook(void);
uint8_t SysTick_Init(void);
uint32_t get_miliseconds(void);
uint32_t get_core_ticks(void);

#endif /* SYSTICKHANDLE_H_ */
