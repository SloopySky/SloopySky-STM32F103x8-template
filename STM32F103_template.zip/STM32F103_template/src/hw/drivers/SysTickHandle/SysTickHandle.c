#include "SysTickHandle.h"
#ifdef USE_RTOS_SYSTICK
#include <cmsis_os.h>
#endif
#include "stm32f1xx_it.h"

#define TICKS_PER_SECOND		SystemCoreClock
#define MILISECONDS_PER_SECOND	1000

static uint32_t miliseconds_counter = 0;
static uint32_t ticks_per_ms = 0;

void SysTick_Handler(void)
{
	miliseconds_counter++;
	SysTick_Hook();
#ifdef USE_RTOS_SYSTICK
	osSystickHandler();
#endif
}

uint8_t SysTick_Init(void) {
	SystemCoreClockUpdate();
	ticks_per_ms = TICKS_PER_SECOND / MILISECONDS_PER_SECOND;
	uint8_t status = SysTick_Config(ticks_per_ms);
	return status;	/* 0 - OK, 1 - NOK */
}

uint32_t get_miliseconds(void) {
	return miliseconds_counter;
}

uint32_t get_core_ticks(void) {
	return  ticks_per_ms * miliseconds_counter;
}
