#include "GPIO.h"
#include <stdbool.h>


static uint8_t calculate_shift(uint8_t bit_position);

/***********************/
/* DIGITAL OUTPUT PART */
/***********************/
void digital_output_init(GPIO_TypeDef* port, GPIO_Pin_t pin) {
	/* Prepare:
	 * CNF1 = 0, CNF0 = 0: General Purpose Output - push-pull
	 * MODE1 = 1, MODE0 = 0: Maximum output speed 2 Mhz
	 */
	uint8_t pin_config = 0b0010;

	for (uint8_t bit_position = 0; bit_position < 16; bit_position++){
		uint16_t position_mask = (1 << bit_position);
		/* Check if pin on the bit_position is selected */
		if (READ_BIT(pin, position_mask) == true) {
			uint8_t shift = calculate_shift(bit_position);

			uint32_t clear_mask = (0b1111 << shift);
			uint32_t set_mask = (pin_config << shift);

			/* Pins from 0 to 7 */
			if (bit_position < 8) {
				MODIFY_REG(port->CRL, clear_mask, set_mask);
			}
			/* Pins from 8 to 15 */
			else {
				MODIFY_REG(port->CRH, clear_mask, set_mask);
			}
		}
	}
}

static uint8_t calculate_shift(uint8_t bit_position) {
	uint8_t shift = bit_position;
	if (bit_position >= 8) {
		/* Count positions in register from zero */
		shift -= 8;
	}
	/* Multiply by number of config bits */
	shift *= 4;

	return shift;
}

void pin_set(GPIO_TypeDef* port, GPIO_Pin_t pin) {
	SET_BIT(port->ODR, pin);
}

void pin_reset(GPIO_TypeDef* port, GPIO_Pin_t pin) {
	CLEAR_BIT(port->ODR, pin);
}

void pin_toggle(GPIO_TypeDef* port, GPIO_Pin_t pin) {
	TOGGLE_BIT(port->ODR, pin);
}
